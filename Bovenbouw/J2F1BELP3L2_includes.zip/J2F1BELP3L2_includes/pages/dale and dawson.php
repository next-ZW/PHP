<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dale & dawson</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>dale & dawson</h1>

  <p>In "Dale & Dawson Stationery Supplies" speel je als Manager, Specialist of Slacker in een kantooromgeving. Slackers mengen zich erin en bootsen Specialisten na om de argwaan van de Manager te vermijden. Ontdek of veroorzaak bedrog om te winnen.</p>

</body>
</html>

<!-- jouw HTML met de inhoud over onderwerp 3 komt hier... -->