<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rainbow six siege</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Rainbow six siege</h1>

</body>
  <p>Rainbow Six Siege is een tactische shooter van Ubisoft die in december 2015 uitkwam. In tegenstelling tot eerdere delen in de Tom Clancy’s Rainbow Six-serie, draait Siege vooral om multiplayer en teamwork, niet zozeer om een singleplayercampagne. Je speelt in teams van vijf tegen elkaar en de game is super strategisch, dus het gaat niet alleen om snel schieten, maar vooral om goed samenwerken en slimme keuzes maken.  </p>

  <p>Wat Rainbow Six Siege echt vet maakt, is dat bijna alles kapot kan. Je kunt muren, vloeren en plafonds opblazen om nieuwe paden te maken of om vijanden te verrassen. Dit maakt de game mega onvoorspelbaar, want elk potje kan compleet anders verlopen. De spanning zit erin dat je niet altijd weet waar de tegenstanders vandaan komen.</p>

  <p>Elke speler kiest een Operator met unieke skills, verdeeld over aanvallers en verdedigers. De juiste combinatie van Operators kiezen is superbelangrijk, omdat elke Operator een andere rol heeft binnen het team.</p>

  <p>Ubisoft blijft de game updaten met nieuwe seizoenen, waarbij ze telkens nieuwe Operators, maps en skins toevoegen. Hierdoor blijft de game fris en uitdagend. Rainbow Six Siege heeft ook een flinke plek in de esports-scene, met grote toernooien en een actieve community die constant blijft groeien.</p>
</html>
<!-- jouw HTML met de inhoud over onderwerp 2 komt hier... -->